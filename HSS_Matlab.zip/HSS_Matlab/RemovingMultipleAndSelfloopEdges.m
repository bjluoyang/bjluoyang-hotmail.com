function [ node_pair, new2old_indicator ] = RemovingMultipleAndSelfloopEdges( node_pair )
   node_pair                        = node_pair + 1;
   old_node_ID                      = sort( unique( node_pair ) );
   num_old_node_ID                  = length( old_node_ID );
   max_old_node_ID                  = max( old_node_ID );
   new2old_indicator                = old_node_ID - 1;
   old2new_indicator                = zeros( 1, max_old_node_ID );
   old2new_indicator( old_node_ID ) = [ 1: 1: num_old_node_ID ];
   node_pair                        = old2new_indicator( node_pair );
   n                                = num_old_node_ID;
   node_pair                        = sort( node_pair, 2 );
   num_edge                         = length( node_pair );
   indicator                        = zeros( 1, num_edge + 1 );
   for i = 1: 1: num_edge
       if node_pair( i, 1 ) ~= node_pair( i, 2 ) & new2old_indicator( node_pair( i, 1 ) ) ~= 0
           indicator( i )           = ( node_pair( i, 1 ) - 1 )*n + node_pair( i, 2 );
       end
   end
   [ uni, pos ]                     = unique( indicator );
   pos                              = setdiff( pos, pos( 1 ) );
   node_pair                        = node_pair( pos, : );
end