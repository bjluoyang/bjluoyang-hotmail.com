function [ sampled_core_graph ] = CoreGraphSamplingNew( core_graph, sampled_bipartite_graph, reduction_ratio )
    rem_edg_num                                                            = length( core_graph )*( 1 - reduction_ratio );
    BP_cor_nod_set                                                         = unique( sampled_bipartite_graph( :, 1 ) );
    BP_cor_nod_num                                                         = length( BP_cor_nod_set );
    cor_gra_nod_set                                                        = unique( core_graph( : ) );
    rem_nod_set                                                            = intersect( cor_gra_nod_set, BP_cor_nod_set );    
    [ component, pointer, component_cardinalities ]                        = GetConnectedComponentsNew( core_graph );
    [ component, pointer, component_cardinalities, com_ratio ]             = RemainConnectedCommponents( component, pointer, component_cardinalities, rem_nod_set );    
    [ max_cardinality, max_component_id ]                                  = max( component_cardinalities );
    if max_component_id == 1
        max_component                                                      = component( [ 1: 1: pointer( 1 ) ], : );
    else
        max_component                                                      = component( [ pointer( max_component_id - 1 ) + 1: 1: pointer( max_component_id ) ], : );
    end
    if length( max_component ) >= rem_edg_num  
        [ sampled_core_graph ]                                             = CoreFastIncreaseEdges( max_component, rem_nod_set, rem_edg_num );           
    else        
        sampled_core_graph                                                 = SamplingConnectedComponents( component, pointer, rem_edg_num );
    end
end