function [ SampledComponent ] = SamplingConnectedComponents( component, pointer, sampled_edge_num )
    edge_num                                                               = length( component );
    component_num                                                          = length( pointer );
    edge_num_dist                                                          = pointer( [ 1: 1: component_num ] ) - [ 0, pointer( [ 1: 1: component_num - 1 ] ) ];
    edge_num_prob                                                          = edge_num_dist/sum( edge_num_dist );
    list_length                                                            = 3*component_num;
    sampled_component_list                                                 = randsrc( 1, list_length, [ [ 1: 1: component_num ]; edge_num_prob ] );
    cur_edge_num                                                           = 0;
    sampled_component_label                                                = zeros( 1, component_num );
    for id = 1: 1: list_length
        component_id                                                       = sampled_component_list( id );
        if sampled_component_label( component_id ) == 0            
            sampled_component_label( component_id )                        = 1;
            cur_edge_num                                                   = cur_edge_num + edge_num_dist( component_id );
            if cur_edge_num >= sampled_edge_num
                break;
            end
        end
    end  
    sampled_component_ids                                                  = find( sampled_component_label == 1 );
    sampled_component_num                                                  = length( sampled_component_ids );
    sampled_edge_ids                                                       = zeros( 1, edge_num );
    edge_pointer                                                           = 0;
    for id = 1: 1: sampled_component_num
        component_id                                                       = sampled_component_ids( id );
        if component_id == 1
            sampled_edge_ids( [ edge_pointer + 1: 1: edge_pointer + edge_num_dist( component_id ) ] )...
                                                                           = [ 1: 1: pointer( component_id ) ];            
        else
            sampled_edge_ids( [ edge_pointer + 1: 1: edge_pointer + edge_num_dist( component_id ) ] )...
                                                                           = [ pointer( component_id - 1 ) + 1: 1: pointer( component_id ) ];   
        end
        edge_pointer                                                       = edge_pointer + edge_num_dist( component_id );
    end
    sampled_edge_ids                                                       = sampled_edge_ids( [ 1: 1: edge_pointer ] );
    SampledComponent                                                       = component( sampled_edge_ids, : );
end