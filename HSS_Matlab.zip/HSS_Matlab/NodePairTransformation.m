function [ node_pair, n, m, new2old_indicator ] = NodePairTransformation( node_pair )
    old_node_ID                                                            = sort( unique( node_pair ) );
    new2old_indicator                                                      = old_node_ID;
    num_old_node_ID                                                        = length( old_node_ID );
    max_old_node_ID                                                        = max( old_node_ID );     
    [ is_inc, node_pair ]                                                  = ismember( node_pair, old_node_ID );
    n                                                                      = num_old_node_ID;
    m                                                                      = length( node_pair );
end