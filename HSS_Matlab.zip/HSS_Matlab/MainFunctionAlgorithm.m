%address
fullpath                                                                   = mfilename('fullpath');
fullpath                                                                   = fullpath( [ 1: length( fullpath ) - 21 ] );
original_graph_addgress                                                    = strcat( fullpath, 'Eurosis.txt' );
write_address                                                              = strcat( fullpath, 'SampledEurosis.txt' );
rand( 'seed', 0 );
%inputs
sampling_rate                                                              = 0.30;
centrum_ratio                                                              = 0.30;
rough_tuning_ratio                                                         = 0.60;
per_select                                                                 = 1; % per_select = 2 if the size of the largest connected component of the periphery is extremely small otherwise per_select = 1
%sampling process
[ sampled_graph, sampled_core_graph, sampled_bipartite_graph, sampled_periphery_graph, original_graph ]...
                                                                           = ScaleFreeSamplingAlgorithm( original_graph_addgress, sampling_rate, centrum_ratio, rough_tuning_ratio, per_select );
%store data
sampled_graph                                                              = sort( sampled_graph, 2 );
fid_w                                                                      = fopen( write_address, 'w' );
fprintf( fid_w, '%d %d \r\n', sampled_graph' );
fclose( fid_w );