function [ node_degree, nei_pointer, nei_node_sets ] = GetNeiNodeSets( node_pair, n, m )
    node_degree                                                            = zeros( 1, n );
    nei_pointer                                                            = zeros( 1, n );
    nei_node_sets                                                          = zeros( 1, 2*m );
    for i = 1: 1: m
        node_degree( node_pair( i, 1 ) )                                   = node_degree( node_pair( i, 1 ) ) + 1;
        node_degree( node_pair( i, 2 ) )                                   = node_degree( node_pair( i, 2 ) ) + 1;
    end
    nei_pointer( 1 )                                                       = 1;
    for i = 2: 1: n
        nei_pointer( i )                                                   = nei_pointer( i - 1 ) + node_degree( i - 1 );
    end
    tem_data                                                               = zeros( 1, n );
    for i = 1: 1: m
        node1                                                              = node_pair( i, 1 );
        node2                                                              = node_pair( i, 2 );
        tem_data( node1 )                                                  = tem_data( node1 ) + 1;
        tem_data( node2 )                                                  = tem_data( node2 ) + 1;
        nei_node_sets( nei_pointer( node1 ) + tem_data( node1 ) - 1 )      = node2;
        nei_node_sets( nei_pointer( node2 ) + tem_data( node2 ) - 1 )      = node1;
    end
end