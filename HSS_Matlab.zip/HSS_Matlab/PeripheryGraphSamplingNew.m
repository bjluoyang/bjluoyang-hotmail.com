function [ sampled_periphery_sma_subcomponent ] = PeripheryGraphSamplingNew( periphery_sma_subcomponent, periphery_sma_pointer, periphery_cardinalities, sma_rem_num, sampled_bipartite_graph, per_select, reduction_ratio )
    BP_per_nod_set                                                         = unique( sampled_bipartite_graph( :, 2 ) );
    per_gra_nod_set                                                        = unique( periphery_sma_subcomponent( : ) );
    rem_nod_set                                                            = intersect( per_gra_nod_set, BP_per_nod_set ); 
    [ component, pointer, component_cardinalities, com_ratio ]             = RemainConnectedCommponents( periphery_sma_subcomponent, periphery_sma_pointer, periphery_cardinalities, rem_nod_set ); 
    if length( component ) == 0
        sampled_periphery_sma_subcomponent                                 = zeros( 0, 2 );
        return;
    end
    if per_select == 1
        cur_edge_num                                                       = 0;
        com_nod_rat                                                        = com_ratio( 1, : )./com_ratio( 2, : );
        [ sor, component_list ]                                            = sort( com_nod_rat, 'descend' );
        component_list_length                                              = length( component_list );
        for seg_id = 1: 1: component_list_length
            cur_edge_num                                                   = cur_edge_num + component_cardinalities( component_list( seg_id ) );
            if cur_edge_num >= sma_rem_num
                break;
            end        
        end      
        sampled_component_ids                                              = component_list( [ 1: 1: seg_id ] );
    elseif per_select == 2
        cur_edge_num                                                       = 0;
        com_nod_rat                                                        = com_ratio( 2, : ) - com_ratio( 1, : );
        [ sor, component_list ]                                            = sort( com_nod_rat, 'descend' );
        component_list_length                                              = length( component_list );
        for seg_id = 1: 1: component_list_length
            cur_edge_num                                                   = cur_edge_num + component_cardinalities( component_list( seg_id ) );
            if cur_edge_num >= sma_rem_num*1.3
                break;
            end        
        end      
        sampled_component_ids                                              = component_list( [ 1: 1: seg_id ] );        
    end
    sampled_component_num                                                  = length( sampled_component_ids );
    edg_pointer                                                            = 0;
    for id = 1: 1: sampled_component_num
        component_id                                                       = sampled_component_ids( id );
        if component_id == 1
            sampled_edg_ids( [ edg_pointer + 1: 1: edg_pointer + component_cardinalities( component_id ) ] )...
                                                                           = [ 1: 1: pointer( component_id ) ];            
        else
            sampled_edg_ids( [ edg_pointer + 1: 1: edg_pointer + component_cardinalities( component_id ) ] )...
                                                                           = [ pointer( component_id - 1 ) + 1: 1: pointer( component_id ) ];   
        end
        edg_pointer                                                        = edg_pointer + component_cardinalities( component_id );
    end
    sampled_periphery_sma_subcomponent                                     = component( sampled_edg_ids( [ 1: 1: edg_pointer ] ), : );
end