function [ sampled_graph ] = ForestFireNoRestrict( original_graph, rem_edg_num, bart )
    [ new_id_paris, n, m, new2old_indicator ]                              = NodePairTransformation( original_graph );
    [ node_degree, nei_pointer, nei_node_sets ]                            = GetNeiNodeSets( new_id_paris, n, m );
    sampled_pair_indicator                                                 = 0; 
    node_indicator                                                         = zeros( 1, n );
    [max_value, max_deg_nod ]                                              = max( node_degree );
    while sampled_pair_indicator < rem_edg_num
        eff_nodes                                                          = find( node_indicator == 0 );
        if length( eff_nodes ) == 0
            break;
        end
        if sampled_pair_indicator == 0
            seed_node                                                      = max_deg_nod;
        else
            seed_node                                                      = eff_nodes( randi( length( eff_nodes ), 1, 1 ) );
        end            
        component_list                                                     = zeros( 1, n );    
        component_list( 1 )                                                = seed_node;    
        current_pointer                                                    = 1;
        middle_pointer                                                     = 1;
        neighbor_pointer                                                   = 1;
        while middle_pointer - current_pointer >= 0
            node                                                           = component_list( current_pointer );
            node_indicator( node )                                         = 1;
            neighbors                                                      = nei_node_sets( [ nei_pointer( node ): 1: nei_pointer( node ) + node_degree( node ) - 1 ] );
            addedg_neighbors                                               = intersect( neighbors, find( node_indicator == 1 ) );
            sampled_pair_indicator                                         = sampled_pair_indicator + length( addedg_neighbors );
            extend_neighbors                                               = setdiff( neighbors, addedg_neighbors );
            extend_neighbors                                               = setdiff( extend_neighbors, component_list( [ current_pointer + 1: 1: neighbor_pointer ] ) );
            forward_burning_num                                            = random( 'Geometric', 1 - bart, 1, 1 );
            len_neighbors                                                  = length( extend_neighbors );
            if len_neighbors >= forward_burning_num
                extend_neighbors                                           = extend_neighbors( randperm( len_neighbors, forward_burning_num ) );          
                len_neighbors                                              = forward_burning_num;
            end       
            component_list( [ neighbor_pointer + 1: 1: neighbor_pointer + len_neighbors ] )...
                                                                           = extend_neighbors;
            neighbor_pointer                                               = neighbor_pointer + len_neighbors;
            if current_pointer == middle_pointer
                current_pointer                                            = middle_pointer + 1;
                middle_pointer                                             = neighbor_pointer;
            else
                current_pointer                                            = current_pointer + 1;
            end              
            if sampled_pair_indicator >= rem_edg_num
                break;
            end            
        end
    end
    sampled_nodes                                                          = find( node_indicator == 1 );                       
    f_position                                                             = find( ismember( new_id_paris( :, 1 ), sampled_nodes ) == 1 );
    l_position                                                             = find( ismember( new_id_paris( :, 2 ), sampled_nodes ) == 1 );   
    sampled_pair_ids                                                       = intersect( f_position, l_position );
    sampled_graph                                                          = new2old_indicator( new_id_paris( sampled_pair_ids, : ) );
end