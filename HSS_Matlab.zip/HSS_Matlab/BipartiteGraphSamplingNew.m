function [ BP_sampled_graph, bipartite_sampling_ratio ] = BipartiteGraphSamplingNew( bipartite_graph, sampled_periphery_graph, reduction_ratio, cor_top_ratio, cor_per_low_deg_adj )
    [ p_Matrix, n, m, new2old_indicator ]                                  = NodePairTransformation( bipartite_graph ); 
    [ node_degree, nei_pointer, nei_node_sets ]                            = GetNeiNodeSets( p_Matrix, n, m );
    cor_layer_nod_set                                                      = unique( p_Matrix( :, 1 ) )';
    per_layer_nod_set                                                      = unique( p_Matrix( :, 2 ) )';
    [ cor_deg_dis, per_deg_dis, cor_deg_num, per_deg_num ]                 = GetBipartiteGraphDegreeDistribution( node_degree, new2old_indicator, cor_layer_nod_set, per_layer_nod_set );
    cor_deg_len                                                            = length( cor_deg_dis );    
    cor_deg_sum                                                            = sum( cor_deg_num );
    cor_deg_count                                                          = 0;
    for id = cor_deg_len: -1: 1
        cor_deg_count                                                      = cor_deg_count + cor_deg_num( id );
        if cor_deg_count >= cor_deg_sum*cor_top_ratio
            break;
        end
    end
    cor_max_deg                                                            = cor_deg_dis( 1, id );
    per_max_deg                                                            = per_deg_dis( 1, length( per_deg_dis ) );
    periphery_graph_node_set                                               = unique( sampled_periphery_graph( : ) );
    [ is_inc, per_gra_nod_set ]                                            = ismember( periphery_graph_node_set, new2old_indicator );
    per_gra_nod_set                                                        = per_gra_nod_set( find( per_gra_nod_set > 0 ) );  
    pp_Matrix                                                              = node_degree( p_Matrix );
    all_edg_num                                                            = length( pp_Matrix );
    deg_inc_mat                                                            = zeros( cor_max_deg, per_max_deg );
    for id = 1: 1: all_edg_num
        if pp_Matrix( id, 1 ) <= cor_max_deg
            deg_inc_mat( pp_Matrix( id, 1 ), pp_Matrix( id, 2 ) )          = deg_inc_mat( pp_Matrix( id, 1 ), pp_Matrix( id, 2 ) ) + 1;
        end
    end
    inc_nod_set                                                            = cor_layer_nod_set( find( node_degree( cor_layer_nod_set ) > cor_max_deg ) );    
    [ sor, pos ]                                                           = sort( node_degree( inc_nod_set ), 'descend' );
    inc_nod_set                                                            = inc_nod_set( pos );
    inc_nod_num                                                            = length( inc_nod_set );
    nod_inc_mat                                                            = zeros( inc_nod_num, per_max_deg );
    for nod_id = 1: 1: inc_nod_num
        cur_nod                                                            = inc_nod_set( nod_id );
        cur_nod_nei                                                        = nei_node_sets( [ nei_pointer( cur_nod ): 1: nei_pointer( cur_nod ) + node_degree( cur_nod ) - 1 ] );
        nod_nei_deg                                                        = node_degree( cur_nod_nei );
        for per_deg = 1: 1: per_max_deg
            nod_inc_mat( nod_id, per_deg )                                 = length( find( nod_nei_deg == per_deg ) );
        end
    end    
    [ BP_sampled_matrix, bipartite_sampling_ratio ]                        = SamplingBGProcessNew( p_Matrix, n, node_degree, nei_pointer, nei_node_sets, deg_inc_mat, nod_inc_mat, inc_nod_set, inc_nod_num, cor_layer_nod_set, per_layer_nod_set, all_edg_num, reduction_ratio, cor_max_deg, per_max_deg, per_gra_nod_set, cor_per_low_deg_adj );
    BP_sampled_graph                                                       = new2old_indicator( BP_sampled_matrix );
end