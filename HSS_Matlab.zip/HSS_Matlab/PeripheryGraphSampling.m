function [ sampled_periphery_big_subcomponent, sampled_periphery_sma_subcomponent, periphery_sma_subcomponent, periphery_sma_pointer, periphery_cardinalities, sma_rem_num ] = PeripheryGraphSampling( periphery_graph, bipartite_graph, reduction_ratio, per_select )
    per_edg_num                                                            = length( periphery_graph );
    rem_edg_num                                                            = round( per_edg_num*( 1 - reduction_ratio ) );    
    BP_per_nod_set                                                         = unique( bipartite_graph( :, 2 ) );
    per_gra_nod_set                                                        = unique( periphery_graph( : ) );
    rem_nod_set                                                            = intersect( per_gra_nod_set, BP_per_nod_set ); 
    [ component, pointer, component_cardinalities ]                        = GetConnectedComponentsNew( periphery_graph );
    [ component, pointer, component_cardinalities, com_ratio ]             = RemainConnectedCommponents( component, pointer, component_cardinalities, rem_nod_set ); 
    cardinalities                                                          = component_cardinalities/sum( component_cardinalities );
    [ max_value, big_com_ids ]                                             = max( cardinalities );
    sma_com_ids                                                            = setdiff( [ 1: length( cardinalities ) ], big_com_ids ); 
    sampled_edg_ids                                                        = zeros( 1, length( component ) );
    big_com_num                                                            = length( big_com_ids );  
    edg_pointer                                                            = 0;
    for id = 1: 1: big_com_num
        component_id                                                       = big_com_ids( id );
        if component_id == 1
            sampled_edg_ids( [ edg_pointer + 1: 1: edg_pointer + component_cardinalities( component_id ) ] )...
                                                                           = [ 1: 1: pointer( component_id ) ];            
        else
            sampled_edg_ids( [ edg_pointer + 1: 1: edg_pointer + component_cardinalities( component_id ) ] )...
                                                                           = [ pointer( component_id - 1 ) + 1: 1: pointer( component_id ) ];   
        end
        edg_pointer                                                        = edg_pointer + component_cardinalities( component_id );
    end
    periphery_big_subcomponent                                             = component( sampled_edg_ids( [ 1: 1: edg_pointer ] ), : );
    sma_com_num                                                            = length( sma_com_ids );  
    edg_pointer                                                            = 0;
    periphery_sma_pointer                                                  = zeros( 1, sma_com_num );
    periphery_cardinalities                                                = zeros( 1, sma_com_num );
    for id = 1: 1: sma_com_num
        component_id                                                       = sma_com_ids( id );
        if component_id == 1
            sampled_edg_ids( [ edg_pointer + 1: 1: edg_pointer + component_cardinalities( component_id ) ] )...
                                                                           = [ 1: 1: pointer( component_id ) ];              
        else
            sampled_edg_ids( [ edg_pointer + 1: 1: edg_pointer + component_cardinalities( component_id ) ] )...
                                                                           = [ pointer( component_id - 1 ) + 1: 1: pointer( component_id ) ];   
        end
        edg_pointer                                                        = edg_pointer + component_cardinalities( component_id );
        periphery_sma_pointer( id )                                        = edg_pointer;
        periphery_cardinalities( id )                                      = component_cardinalities( component_id );
    end
    periphery_sma_subcomponent                                             = component( sampled_edg_ids( [ 1: 1: edg_pointer ] ), : );
    big_rem_num                                                            = round( rem_edg_num*sum( component_cardinalities( big_com_ids ) )/sum( component_cardinalities ) );
    [ sampled_periphery_big_subcomponent ]                                 = ForestFireNoRestrict( periphery_big_subcomponent, big_rem_num, 0.7 ); 
    if per_select == 1
        sma_rem_num                                                        = rem_edg_num - length( sampled_periphery_big_subcomponent );
        cur_edge_num                                                       = 0;
        com_nod_rat                                                        = com_ratio( 1, : )./com_ratio( 2, : );
        [ sor, component_list ]                                            = sort( com_nod_rat( sma_com_ids ), 'descend' );
        component_list_length                                              = length( component_list );
        for seg_id = 1: 1: component_list_length
            cur_edge_num                                                   = cur_edge_num + component_cardinalities( sma_com_ids( component_list( seg_id ) ) );
            if cur_edge_num >= sma_rem_num
                break;
            end        
        end      
        sampled_component_ids                                              = sma_com_ids( component_list( [ 1: 1: seg_id ] ) );
    elseif per_select == 2
        sma_rem_num                                                        = rem_edg_num - length( sampled_periphery_big_subcomponent );
        cur_edge_num                                                       = 0;
        com_nod_rat                                                        = com_ratio( 2, : ) - com_ratio( 1, : );
        [ sor, component_list ]                                            = sort( com_nod_rat( sma_com_ids ), 'descend' );
        component_list_length                                              = length( component_list );
        for seg_id = 1: 1: component_list_length
            cur_edge_num                                                   = cur_edge_num + component_cardinalities( sma_com_ids( component_list( seg_id ) ) );
            if cur_edge_num >= sma_rem_num*1.3
                break;
            end        
        end      
        sampled_component_ids                                              = sma_com_ids( component_list( [ 1: 1: seg_id ] ) );
    end
    sampled_component_num                                                  = length( sampled_component_ids );
    edg_pointer                                                            = 0;
    for id = 1: 1: sampled_component_num
        component_id                                                       = sampled_component_ids( id );
        if component_id == 1
            sampled_edg_ids( [ edg_pointer + 1: 1: edg_pointer + component_cardinalities( component_id ) ] )...
                                                                           = [ 1: 1: pointer( component_id ) ];            
        else
            sampled_edg_ids( [ edg_pointer + 1: 1: edg_pointer + component_cardinalities( component_id ) ] )...
                                                                           = [ pointer( component_id - 1 ) + 1: 1: pointer( component_id ) ];   
        end
        edg_pointer                                                        = edg_pointer + component_cardinalities( component_id );
    end
    sampled_periphery_sma_subcomponent                                     = component( sampled_edg_ids( [ 1: 1: edg_pointer ] ), : );
end