function [ core_graph, bipartite_graph, periphery_graph, original_graph ] = BipartiteGraphDecomposition( original_graph_addgress )
    original_graph                                                         = load( original_graph_addgress );    
    original_graph                                                         = original_graph( :, [ 1, 2 ] );
    [ original_graph, new2old_indicator ]                                  = RemovingMultipleAndSelfloopEdges( original_graph );
    [ component, pointer, component_cardinalities ]                        = GetConnectedComponentsNew( original_graph );
    [ max_cardinality, max_component_id ]                                  = max( component_cardinalities );
    if max_component_id == 1
        original_graph                                                     = component( [ 1: 1: pointer( 1 ) ], : );
    else
        original_graph                                                     = component( [ pointer( max_component_id - 1 ) + 1: 1: pointer( max_component_id ) ], : );
    end
    [ original_graph, n, m, new2old_indicator ]                            = NodePairTransformation( original_graph );    
    original_graph                                                         = sort( original_graph, 2 );
    [ ori_node_degree, ori_nei_pointer, ori_nei_node_sets ]                = GetNeiNodeSets( original_graph, n, m );
    [ ori_sor_deg, ori_sor_nod ]                                           = sort( ori_node_degree );
    ori_deg_type                                                           = unique( ori_sor_deg );
    ori_deg_num                                                            = length( ori_deg_type );
    f_bip_edg_num                                                          = 0;
    f_per_edg_num                                                          = 0;
    for deg_id = 1: 1: ori_deg_num
        deg                                                                = ori_deg_type( deg_id );
        periphery_nod_set                                                  = ori_sor_nod( find( ori_sor_deg <= deg ) );
        core_nod_set                                                       = setdiff( [ 1: 1: n ], periphery_nod_set );
        cor_pos_1                                                          = find( ismember( original_graph( :, 1 ), core_nod_set ) == 1 );
        per_pos_2                                                          = find( ismember( original_graph( :, 2 ), periphery_nod_set ) == 1 );
        cor_per_graph_1                                                    = original_graph( intersect( cor_pos_1, per_pos_2 ), [ 1, 2 ] );
        cor_pos_2                                                          = find( ismember( original_graph( :, 2 ), core_nod_set ) == 1 );
        per_pos_1                                                          = find( ismember( original_graph( :, 1 ), periphery_nod_set ) == 1 );
        cor_per_graph_2                                                    = original_graph( intersect( cor_pos_2, per_pos_1 ), [ 2, 1 ] );
        cur_bipartite_graph                                                = [ cor_per_graph_1; cor_per_graph_2 ];
        cur_periphery_graph                                                = original_graph( intersect( per_pos_1, per_pos_2 ), : );
        cur_core_graph                                                     = original_graph( intersect( cor_pos_1, cor_pos_2 ), : );
        bip_edg_add                                                        = length( cur_bipartite_graph ) - f_bip_edg_num;
        per_edg_add                                                        = length( cur_periphery_graph ) - f_per_edg_num;       
         if bip_edg_add <= 0            
            break;
        else  
            f_bip_edg_num                                                  = length( cur_bipartite_graph );
            f_per_edg_num                                                  = length( cur_periphery_graph );
            core_graph                                                     = cur_core_graph;
            bipartite_graph                                                = cur_bipartite_graph;
            periphery_graph                                                = cur_periphery_graph;
        end
    end
end