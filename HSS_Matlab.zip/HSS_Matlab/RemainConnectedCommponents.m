function [ component, pointer, component_cardinalities, com_ratio ] = RemainConnectedCommponents( component, pointer, component_cardinalities, rem_nod_set )
    [ is_inc_1, edg_pos_1 ]                                                = ismember( rem_nod_set, component( :, 1 ) );
    pos_1                                                                  = find( is_inc_1 == 0 );
    [ is_inc_2, edg_pos_2 ]                                                = ismember( rem_nod_set( pos_1 ), component( :, 2 ) );
    edg_pos_1( pos_1 )                                                     = edg_pos_2;
    rem_nod_num                                                            = length( rem_nod_set );
    con_com_ind                                                            = zeros( 1, rem_nod_num );
    for id = 1: 1: rem_nod_num
        con_com_ind( id )                                                  = min( find( pointer >= edg_pos_1( id ) ) );        
    end
    con_com                                                                = unique( con_com_ind );
    if length( con_com ) == 1
        his_num                                                            = length( con_com_ind );
    else
        his_num                                                            = hist( con_com_ind, con_com );
    end
    com_num                                                                = length( con_com );
    sel_num                                                                = zeros( 1, com_num );
    avg_deg                                                                = zeros( 1, com_num );
    edge_num                                                               = length( component );
    sampled_edge_ids                                                       = zeros( 1, edge_num );
    edge_pointer                                                           = 0;
    pointer_new                                                            = zeros( 1, com_num );
    component_num                                                          = length( pointer );
    edge_num_dist                                                          = pointer( [ 1: 1: component_num ] ) - [ 0, pointer( [ 1: 1: component_num - 1 ] ) ];
    for id = 1: 1: com_num
        component_id                                                       = con_com( id );
        if component_id == 1
            sampled_edge_ids( [ edge_pointer + 1: 1: edge_pointer + edge_num_dist( component_id ) ] )...
                                                                           = [ 1: 1: pointer( component_id ) ];           
            cur_component                                                  = component( [ 1: 1: pointer( component_id ) ], : );
        else
            sampled_edge_ids( [ edge_pointer + 1: 1: edge_pointer + edge_num_dist( component_id ) ] )...
                                                                           = [ pointer( component_id - 1 ) + 1: 1: pointer( component_id ) ];  
            cur_component                                                  = component( [ pointer( component_id - 1 ) + 1: 1: pointer( component_id ) ], : );
        end
        edge_pointer                                                       = edge_pointer + edge_num_dist( component_id );
        pointer_new( id )                                                  = edge_pointer;
        
        sel_num( id )                                                      = length( unique( cur_component( : ) ) );
        [ x, y ]                                                           = size( cur_component );
        if x == 1 & y == 2
            edge_number                                                    = 1;
        else
            edge_number                                                    = x;
        end
        avg_deg( id )                                                      = 2*edge_number/sel_num( id );
    end
    sampled_edge_ids                                                       = sampled_edge_ids( [ 1: 1: edge_pointer ] );
    component                                                              = component( sampled_edge_ids, : );
    pointer                                                                = pointer_new;
    component_cardinalities                                                = component_cardinalities( con_com );
    com_ratio                                                              = [ his_num; sel_num; component_cardinalities; avg_deg ];
end