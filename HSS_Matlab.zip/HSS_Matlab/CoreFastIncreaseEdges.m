function [ core_sampled_graph ] = CoreFastIncreaseEdges( max_component, rem_nod_set, rem_edg_num )
    [ x, y ]                                                               = size( rem_nod_set );
    if x > y
        rem_nod_set                                                        = rem_nod_set';
    end
    max_com_nod_set                                                        = unique( max_component( : ) );
    rem_nod_set                                                            = intersect( rem_nod_set, max_com_nod_set );
    com_edg_num                                                            = length( max_component );
    core_sampled_graph                                                     = zeros( com_edg_num, 2 );
    sampled_indicator                                                      = 0;
    [ p_Matrix, n, m, new2old_indicator ]                                  = NodePairTransformation( max_component ); 
    [ node_degree, nei_pointer, nei_node_sets ]                            = GetNeiNodeSets( p_Matrix, n, m );
    [ is_inc, rem_nod_new ]                                                = ismember( rem_nod_set, new2old_indicator );
    f_pos                                                                  = find( ismember( p_Matrix( :, 1 ), rem_nod_new ) == 1 );
    l_pos                                                                  = find( ismember( p_Matrix( :, 2 ), rem_nod_new ) == 1 );
    f_l_pos                                                                = intersect( f_pos, l_pos );
    sampled_indicator                                                      = length( f_l_pos );    
    cur_exc_nod_num                                                        = 0;
    if sampled_indicator >= rem_edg_num
        [ sampled_indicator, rem_edg_num ]
        [ core_sampled_graph ]                                             = ForestFireNoRestrict( max_component( f_l_pos, : ), rem_edg_num, 0.7 );
    else
        [ is_inc, max_component_new ]                                      = ismember( max_component( f_l_pos, : ), new2old_indicator );
        core_sampled_graph( [ 1: 1: sampled_indicator ], : )               = max_component_new;        
        nod_ind                                                            = zeros( 1, n );
        can_nod                                                            = setdiff( [ 1: 1: n ], rem_nod_new );
        for id = 1: 1: length( rem_nod_new )
            cur_nod                                                        = rem_nod_new( id );
            cur_nod_nei                                                    = nei_node_sets( [ nei_pointer( cur_nod ): 1: nei_pointer( cur_nod ) + node_degree( cur_nod ) - 1 ] );
            nod_ind( cur_nod_nei )                                         = nod_ind( cur_nod_nei ) + 1;
        end
        while sampled_indicator < rem_edg_num
            [ max_value, max_pos ]                                         = max( nod_ind( can_nod ) );
            add_nod                                                        = can_nod( max_pos );
            add_nod_nei                                                    = nei_node_sets( [ nei_pointer( add_nod ): 1: nei_pointer( add_nod ) + node_degree( add_nod ) - 1 ] );
            nod_ind( add_nod_nei )                                         = nod_ind( add_nod_nei ) + 1;
            int_add_nod_nei                                                = intersect( add_nod_nei, rem_nod_new );
            add_nod_nei_num                                                = length( int_add_nod_nei );
            core_sampled_graph( [ sampled_indicator + 1: 1: sampled_indicator + add_nod_nei_num ], : )...
                                                                           = [ add_nod*ones( 1, add_nod_nei_num ); int_add_nod_nei ]';
            sampled_indicator                                              = sampled_indicator + add_nod_nei_num;
            rem_nod_new                                                    = [ rem_nod_new, add_nod ];
            can_nod                                                        = setdiff( can_nod, add_nod ); 
        end
        core_sampled_graph                                                 = new2old_indicator( core_sampled_graph( [ 1: 1: sampled_indicator ], : ) );        
    end
end