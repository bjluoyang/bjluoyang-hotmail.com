function [ sampled_graph, sampled_core_graph, sampled_bipartite_graph, sampled_periphery_graph, original_graph ] = ScaleFreeSamplingAlgorithm( original_graph_addgress, sampling_ratio, cor_top_ratio, cor_per_low_deg_adj, per_select )
    reduction_ratio                                                        = 1 - sampling_ratio;
    [ core_graph, bipartite_graph, periphery_graph, original_graph ]       = BipartiteGraphDecomposition( original_graph_addgress );    
    [ sampled_periphery_big_subcomponent, sampled_periphery_sma_subcomponent, periphery_sma_subcomponent, periphery_sma_pointer, periphery_cardinalities, sma_rem_num ]...
                                                                           = PeripheryGraphSampling( periphery_graph, bipartite_graph, reduction_ratio, per_select );
    sampled_periphery_graph                                                = [ sampled_periphery_big_subcomponent; sampled_periphery_sma_subcomponent ];
    [ sampled_bipartite_graph, bipartite_sampling_ratio ]                  = BipartiteGraphSamplingNew( bipartite_graph, sampled_periphery_graph, reduction_ratio, cor_top_ratio, cor_per_low_deg_adj );
    [ sampled_core_graph ]                                                 = CoreGraphSamplingNew( core_graph, sampled_bipartite_graph, reduction_ratio );
    [ sampled_periphery_sma_subcomponent ]                                 = PeripheryGraphSamplingNew( periphery_sma_subcomponent, periphery_sma_pointer, periphery_cardinalities, sma_rem_num, sampled_bipartite_graph, per_select, reduction_ratio );
    sampled_periphery_graph                                                = [ sampled_periphery_big_subcomponent; sampled_periphery_sma_subcomponent ];
    sampled_graph                                                          = [ sampled_core_graph; sampled_bipartite_graph; sampled_periphery_big_subcomponent; sampled_periphery_sma_subcomponent ];
    [ component, pointer, component_cardinalities ]                        = GetConnectedComponentsNew( sampled_graph );
    [ max_cardinality, max_component_id ]                                  = max( component_cardinalities );
    if max_component_id == 1
        sampled_graph                                                      = component( [ 1: 1: pointer( 1 ) ], : );
    else
        sampled_graph                                                      = component( [ pointer( max_component_id - 1 ) + 1: 1: pointer( max_component_id ) ], : );
    end
end