function [ component, pointer, component_cardinalities ] = GetConnectedComponentsNew( node_pair )
    [ node_pair, n, m, new2old_indicator ]                                 = NodePairTransformation( node_pair );
    node_indicator                                                         = [ 1: 1: n ];
    edg_num                                                                = length( node_pair );
    for edg_id = 1: 1: edg_num
        nod_1                                                              = node_pair( edg_id, 1 );
        nod_2                                                              = node_pair( edg_id, 2 );
        root_1                                                             = FindRootForComponents( node_indicator, nod_1 );
        root_2                                                             = FindRootForComponents( node_indicator, nod_2 );
        if root_1 ~= root_2
            node_indicator( root_2 )                                       = root_1;
        end
    end
    nod_ind                                                                = zeros( 1, n );
    nod_rot_lis                                                            = zeros( 1, n );
    nod_rot_lis_id                                                         = 0;
    for nod_id = 1: 1: n
        if nod_ind( nod_id ) == 0
            nod                                                            = nod_id;
            nod_rot_lis_id                                                 = nod_rot_lis_id + 1;
            nod_rot_lis( nod_rot_lis_id )                                  = nod;
            while node_indicator( nod ) ~= nod
                nod                                                        = node_indicator( nod );
                nod_rot_lis_id                                             = nod_rot_lis_id + 1;
                nod_rot_lis( nod_rot_lis_id )                              = nod;
            end
            node_indicator( nod_rot_lis( [ 1: 1: nod_rot_lis_id ] ) )      = nod;
            nod_ind( nod_rot_lis( [ 1: 1: nod_rot_lis_id ] ) )             = 1;
            nod_rot_lis_id                                                 = 0;
        end
    end
    [ sor_ind, node_id ]                                                   = sort( node_indicator );
    [ uni_ind, unit_id ]                                                   = unique( sor_ind );
    component_num                                                          = length( uni_ind );
    pointer                                                                = zeros( 1, component_num );      
    component                                                              = node_pair;
    pointer_id                                                             = 0;
    component_pos                                                          = zeros( component_num, 2 );   
    component_pos( :, 1 )                                                  = [ 1, unit_id( [ 1: 1: component_num - 1 ] ) + 1 ]';
    component_pos( :, 2 )                                                  = unit_id( [ 1: 1: component_num ] )';
    for component_id = 1: 1: component_num
        component_nodes                                                    = node_id( [ component_pos( component_id, 1 ): 1: component_pos( component_id, 2 ) ] );
        component_edge_id                                                  = find( ismember( node_pair( :, 1 )', component_nodes ) == 1 );
        component_edg_num                                                  = length( component_edge_id );
        component( [ pointer_id+1: 1: pointer_id+component_edg_num ], : )  = node_pair( component_edge_id, : );
        pointer_id                                                         = pointer_id + component_edg_num;
        pointer( component_id )                                            = pointer_id;
    end
    component                                                              = new2old_indicator( component );
    component_cardinalities                                                = pointer( [ 1: 1: component_num ] ) - [ 0, pointer( [ 1: 1: component_num - 1 ] ) ];
end