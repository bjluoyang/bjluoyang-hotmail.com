function [ x, y ] = GetMatrixCoordinate( m, n, pos )
    a                                                                      = fix( pos/m );
    b                                                                      = mod( pos,m );
    if b == 0
        x                                                                  = m;
        y                                                                  = a;
    else
        x                                                                  = b;
        y                                                                  = a + 1;
    end
end