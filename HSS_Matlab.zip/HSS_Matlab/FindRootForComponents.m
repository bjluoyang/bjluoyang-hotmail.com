function [ root ] = FindRootForComponents( nod_ind, nod )
    while nod_ind( nod ) ~= nod
        nod                                                                = nod_ind( nod );
    end
    root                                                                   = nod;
end