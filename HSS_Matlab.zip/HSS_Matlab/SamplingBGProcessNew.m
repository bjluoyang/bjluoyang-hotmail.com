function [ BP_sampled_matrix, bipartite_sampling_ratio ] = SamplingBGProcessNew( p_Matrix, n, node_degree, nei_pointer, nei_node_sets, deg_inc_mat, nod_inc_mat, inc_nod_set, inc_nod_num, cor_layer_nod_set, per_layer_nod_set, all_edg_num, reduction_ratio, cor_max_deg, per_max_deg, per_gra_nod_set, cor_per_low_deg_adj )
    del_edg_num                                                            = round( all_edg_num*reduction_ratio );
    deg_inc_edg_num                                                        = sum( deg_inc_mat( : ) );
    nod_inc_edg_num                                                        = sum( nod_inc_mat( : ) );
    deg_nod_ratio                                                          = deg_inc_edg_num/nod_inc_edg_num;
    deg_inc_mat_obj                                                        = ceil( deg_inc_mat*( 1 - reduction_ratio ) ); 
    nod_inc_mat_obj                                                        = ceil( nod_inc_mat*( 1 - reduction_ratio ) ); 
    for id = 1: 1: 3
        edg_num                                                            = sum( nod_inc_mat_obj( id, : ) );
        if edg_num < cor_max_deg
            nod_inc_mat_obj( id, : )                                       = ceil( nod_inc_mat_obj( id, : )*cor_max_deg/edg_num );
        end
    end    
    ini_deg_inc_dis                                                        = deg_inc_mat/all_edg_num;
    ini_nod_inc_dis                                                        = nod_inc_mat/all_edg_num;
    cur_nod_deg                                                            = node_degree;
    cur2cor_nodtra                                                         = zeros( 1, n );
    cur2cor_nodtra( cor_layer_nod_set )                                    = [ 1: 1: length( cor_layer_nod_set ) ];
    cor2cur_nodtra                                                         = cor_layer_nod_set;
    cur2per_nodtra                                                         = zeros( 1, n );
    cur2per_nodtra( per_layer_nod_set )                                    = [ 1: 1: length( per_layer_nod_set ) ];
    per2cur_nodtra                                                         = per_layer_nod_set;
    cor_nod_deg                                                            = node_degree( cor_layer_nod_set );
    per_nod_deg                                                            = node_degree( per_layer_nod_set );
    [ deg_sor, cor_deg2nod_set ]                                           = sort( cor_nod_deg );
    cor_deg_sor_max_deg                                                    = max( deg_sor );
    cor_deg2nod_ind                                                        = zeros( 1, cor_deg_sor_max_deg + 1 );
    [ deg_uni, deg_pos ]                                                   = unique( deg_sor );
    uni_pointer                                                            = 1;
    for deg = 1: 1: cor_deg_sor_max_deg
        if deg == deg_uni( uni_pointer )
            if uni_pointer == 1
                cor_deg2nod_ind( deg )                                     = 1;
            else
                cor_deg2nod_ind( deg )                                     = deg_pos( uni_pointer - 1 ) + 1;
            end
            uni_pointer                                                    = uni_pointer + 1;
        elseif deg == 1  
            cor_deg2nod_ind( deg )                                         = 1;
        elseif uni_pointer == 1
            cor_deg2nod_ind( deg )                                         = 1;
        else
            cor_deg2nod_ind( deg )                                         = deg_pos( uni_pointer - 1 ) + 1;          
        end
    end  
    cor_deg2nod_ind( cor_deg_sor_max_deg + 1 )                             = length( cor_deg2nod_set ) + 1;
    [ deg_sor, per_deg2nod_set ]                                           = sort( per_nod_deg );
    per_deg_sor_max_deg                                                    = max( deg_sor );
    per_deg2nod_ind                                                        = zeros( 1, per_deg_sor_max_deg + 1 );
    [ deg_uni, deg_pos ]                                                   = unique( deg_sor );
    uni_pointer                                                            = 1;
    for deg = 1: 1: per_deg_sor_max_deg
        if deg == deg_uni( uni_pointer )
            if uni_pointer == 1
                per_deg2nod_ind( deg )                                     = 1;
            else
                per_deg2nod_ind( deg )                                     = deg_pos( uni_pointer - 1 ) + 1;
            end
            uni_pointer                                                    = uni_pointer + 1;
        elseif deg == 1  
            per_deg2nod_ind( deg )                                         = 1;
        elseif uni_pointer == 1
            per_deg2nod_ind( deg )                                         = 1;
        else
            per_deg2nod_ind( deg )                                         = deg_pos( uni_pointer - 1 ) + 1;          
        end
    end  
    per_deg2nod_ind( per_deg_sor_max_deg + 1 )                             = length( per_deg2nod_set ) + 1;
    all_edg_ind                                                            = zeros( 1, all_edg_num );
    for id = 1: 1: all_edg_num
        node_pair                                                          = sort( p_Matrix( id, : ) );
        all_edg_ind( id )                                                  = ( node_pair( 2 ) - 1 )*n + node_pair( 1 );
    end    
    del_edg_ind                                                            = zeros( 1, all_edg_num );
    del_edg_count                                                          = 0;
    cor_deg_nod_num                                                        = cor_deg2nod_ind( [ 2: 1: cor_deg_sor_max_deg + 1 ] ) - cor_deg2nod_ind( [ 1: 1: cor_deg_sor_max_deg ] );   
    ini_cor_deg_dis                                                        = cor_deg_nod_num/sum( cor_deg_nod_num );
    per_deg_nod_num                                                        = per_deg2nod_ind( [ 2: 1: per_deg_sor_max_deg + 1 ] ) - per_deg2nod_ind( [ 1: 1: per_deg_sor_max_deg ] );    
    ini_per_deg_dis                                                        = per_deg_nod_num/sum( per_deg_nod_num );    
    is_first_cor                                                           = 1;    
    is_first_per                                                           = 1;   
    cor_distance                                                           = 1;
    per_distance                                                           = 1;
    while del_edg_count < del_edg_num       
        if mod( del_edg_count, 1000 ) == 0
            del_edg_count
        end     
        if del_edg_count == 0
            [ max_value, per_deg ]                                         = max( nod_inc_mat( 1, : ) );
            inc_nod                                                        = inc_nod_set( 1 );
            inc_nod_id                                                     = 1;
            if nod_inc_mat( inc_nod_id, per_deg ) > nod_inc_mat_obj( inc_nod_id, per_deg )
                cur_step_num                                               = nod_inc_mat( inc_nod_id, per_deg ) - nod_inc_mat_obj( inc_nod_id, per_deg );
            else
                cur_step_num                                               = 1;
            end              
            is_nod0_or_deg1_inc                                            = 0;
        elseif del_edg_count < del_edg_num*cor_per_low_deg_adj
            if deg_inc_edg_num/nod_inc_edg_num < deg_nod_ratio  
                cur_nod_inc_dis                                            = nod_inc_mat/( all_edg_num - del_edg_count );
                dif_nod_inc_dis                                            = cur_nod_inc_dis - ini_nod_inc_dis;
                [ nod_max_value, nod_dif_pos ]                             = max( dif_nod_inc_dis( : ) );
                [ inc_nod_id, per_deg ]                                    = GetMatrixCoordinate( inc_nod_num, per_max_deg, nod_dif_pos );
                inc_nod                                                    = inc_nod_set( inc_nod_id );  
                if nod_inc_mat( inc_nod_id, per_deg ) > nod_inc_mat_obj( inc_nod_id, per_deg )
                    cur_step_num                                           = nod_inc_mat( inc_nod_id, per_deg ) - nod_inc_mat_obj( inc_nod_id, per_deg );
                else
                    cur_step_num                                           = 1;
                end  
                is_nod0_or_deg1_inc                                        = 0;                
            else
                cur_deg_inc_dis                                            = deg_inc_mat/( all_edg_num - del_edg_count );
                dif_deg_inc_dis                                            = cur_deg_inc_dis - ini_deg_inc_dis;
                [ deg_max_value, deg_dif_pos ]                             = max( dif_deg_inc_dis( : ) );
                [ cor_deg, per_deg ]                                       = GetMatrixCoordinate( cor_max_deg, per_max_deg, deg_dif_pos ); 
                if deg_inc_mat( cor_deg, per_deg ) > deg_inc_mat_obj( cor_deg, per_deg )
                    cur_step_num                                           = deg_inc_mat( cor_deg, per_deg ) - deg_inc_mat_obj( cor_deg, per_deg );
                else
                    cur_step_num                                           = 1;
                end  
                is_nod0_or_deg1_inc                                        = 1;
            end                     
        elseif cor_distance >= per_distance
            if is_first_cor == 1
                cor_deg_nod_num                                            = cor_deg2nod_ind( [ 2: 1: cor_deg_sor_max_deg + 1 ] ) - cor_deg2nod_ind( [ 1: 1: cor_deg_sor_max_deg ] );              
                cur_cor_nod_num                                            = sum( cor_deg_nod_num );
                cur_cor_deg_dis                                            = cor_deg_nod_num/cur_cor_nod_num;
                is_first_cor                                               = 0;
            end         
            [ max_value, cor_deg ]                                         = max( cur_cor_deg_dis - ini_cor_deg_dis );   
            if cor_deg <= cor_max_deg
                if step_count > 0
                    cur_deg_inc_dis                                        = deg_inc_mat( cor_deg, : )/( all_edg_num - del_edg_count );
                    dif_deg_inc_dis                                        = cur_deg_inc_dis - ini_deg_inc_dis( cor_deg, : );            
                    eff_per_deg                                            = find( cur_deg_inc_dis > 0 );
                    [ max_value, per_pos ]                                 = max( dif_deg_inc_dis( eff_per_deg ) );
                    per_deg                                                = eff_per_deg( per_pos );
                    if del_edg_count < del_edg_num*( cor_per_low_deg_adj + 0.02 )
                        cur_step_num                                       = max( deg_inc_mat( cor_deg, per_deg ) - deg_inc_mat_obj( cor_deg, per_deg ), 1 );
                    else
                        cur_step_num                                       = 1;
                    end     
                    is_nod0_or_deg1_inc                                    = 1;    
                else
                    inc_nod_ids                                            = find( cur_nod_deg( inc_nod_set ) == cor_deg );
                    cur_nod_inc_dis                                        = nod_inc_mat( inc_nod_ids, : )/( all_edg_num - del_edg_count );
                    dif_nod_inc_dis                                        = cur_nod_inc_dis - ini_nod_inc_dis( inc_nod_ids, : );
                    eff_per_deg                                            = find( cur_nod_inc_dis( : ) > 0 );
                    [ max_value, per_pos ]                                 = max( dif_nod_inc_dis( eff_per_deg ) );
                    [ inc_nod_id, per_deg ]                                = GetMatrixCoordinate( length( inc_nod_ids ), per_max_deg, eff_per_deg( per_pos ) ); 
                    inc_nod_id                                             = inc_nod_ids( inc_nod_id );
                    inc_nod                                                = inc_nod_set( inc_nod_id );
                    is_nod0_or_deg1_inc                                    = 0;
                    cur_step_num                                           = 1;
                end
            else
                inc_nod_ids                                                = find( cur_nod_deg( inc_nod_set ) == cor_deg );
                cur_nod_inc_dis                                            = nod_inc_mat( inc_nod_ids, : )/( all_edg_num - del_edg_count );
                dif_nod_inc_dis                                            = cur_nod_inc_dis - ini_nod_inc_dis( inc_nod_ids, : );
                eff_per_deg                                                = find( cur_nod_inc_dis( : ) > 0 );
                [ max_value, per_pos ]                                     = max( dif_nod_inc_dis( eff_per_deg ) );
                [ inc_nod_id, per_deg ]                                    = GetMatrixCoordinate( length( inc_nod_ids ), per_max_deg, eff_per_deg( per_pos ) ); 
                inc_nod_id                                                 = inc_nod_ids( inc_nod_id );
                inc_nod                                                    = inc_nod_set( inc_nod_id );
                is_nod0_or_deg1_inc                                        = 0;
                cur_step_num                                               = 1;
            end      
        else
            if is_first_per == 1
                per_deg_nod_num                                            = per_deg2nod_ind( [ 2: 1: per_deg_sor_max_deg + 1 ] ) - per_deg2nod_ind( [ 1: 1: per_deg_sor_max_deg ] );                    
                cur_per_nod_num                                            = sum( per_deg_nod_num );
                cur_per_deg_dis                                            = per_deg_nod_num/cur_per_nod_num;
                is_first_per                                               = 0;
            end     
            [ max_value, per_deg ]                                         = max( cur_per_deg_dis - ini_per_deg_dis );            
            cur_deg_inc_dis                                                = deg_inc_mat( :, per_deg )/( all_edg_num - del_edg_count ); 
            eff_cor_deg                                                    = find( cur_deg_inc_dis > 0 );
            if length( eff_cor_deg ) > 0
                dif_deg_inc_dis                                            = cur_deg_inc_dis - ini_deg_inc_dis( :, per_deg );
                [ max_value, cor_pos ]                                     = max( dif_deg_inc_dis( eff_cor_deg ) );
                cor_deg                                                    = eff_cor_deg( cor_pos );  
                if del_edg_count < del_edg_num*( cor_per_low_deg_adj + 0.02 )
                    cur_step_num                                           = max( deg_inc_mat( cor_deg, per_deg ) - deg_inc_mat_obj( cor_deg, per_deg ), 1 );
                else
                    cur_step_num                                           = 1;
                end                  
                is_nod0_or_deg1_inc                                        = 1;
            else
                cur_nod_inc_dis                                            = nod_inc_mat( :, per_deg )/( all_edg_num - del_edg_count );            
                dif_nod_inc_dis                                            = cur_nod_inc_dis - ini_nod_inc_dis( :, per_deg );
                eff_nod_ids                                                = find( cur_nod_inc_dis > 0 );
                [ max_value, nod_id_pos ]                                  = max( dif_nod_inc_dis( eff_nod_ids ) );
                inc_nod_id                                                 = eff_nod_ids( nod_id_pos );
                inc_nod                                                    = inc_nod_set( inc_nod_id );
                cor_deg                                                    = cur_nod_deg( inc_nod );
                if del_edg_count < del_edg_num*( cor_per_low_deg_adj + 0.02 )
                    cur_step_num                                           = max( nod_inc_mat( inc_nod_id, per_deg ) - nod_inc_mat_obj( inc_nod_id, per_deg ), 1 );
                else
                    cur_step_num                                           = 1;
                end 
                is_nod0_or_deg1_inc                                        = 0;
            end   
        end 
        per_nodes                                                          = per2cur_nodtra( per_deg2nod_set( [ per_deg2nod_ind( per_deg ): 1: per_deg2nod_ind( per_deg + 1 ) - 1 ] ) );
        pri_per_del_nodes                                                  = setdiff( per_nodes, per_gra_nod_set );               
        oth_per_del_nodes                                                  = setdiff( per_nodes, pri_per_del_nodes );
        per_nodes                                                          = [ pri_per_del_nodes, oth_per_del_nodes ];         
        per_nod_num                                                        = length( per_nodes );
        step_count                                                         = 0;
        repeat_cor_label                                                   = zeros( 1, cur_step_num );        
        for id = 1: 1: per_nod_num
            cur_per_nod                                                    = per_nodes( id );
            per_nei_nod_set                                                = nei_node_sets( [ nei_pointer( cur_per_nod ): 1: nei_pointer( cur_per_nod ) + cur_nod_deg( cur_per_nod ) - 1 ] );
            is_inc                                                         = ismember( per_nei_nod_set, inc_nod_set );
            per_nei_deg_inc_set                                            = per_nei_nod_set( find( is_inc == 0 ) );
            per_nei_nod_inc_set                                            = per_nei_nod_set( find( is_inc == 1 ) );
            if is_nod0_or_deg1_inc == 1               
                cor_nei_set                                                = intersect( cor2cur_nodtra( cor_deg2nod_set( [ cor_deg2nod_ind( cor_deg ): 1: cor_deg2nod_ind( cor_deg + 1 ) - 1 ] ) ), per_nei_deg_inc_set );
                cor_nei_set                                                = setdiff( cor_nei_set, repeat_cor_label( [ 1: 1: step_count ] ) );
                if length( cor_nei_set ) > 0
                    cur_cor_nod                                            = cor_nei_set( 1 );  
                    repeat_cor_label( step_count + 1 )                     = cur_cor_nod;
                else
                    continue;
                end
            else
                if ismember( inc_nod, per_nei_nod_inc_set )
                    cur_cor_nod                                            = inc_nod;
                    cor_deg                                                = cur_nod_deg( cur_cor_nod );
                else
                    continue;
                end
            end
            node_pair                                                      = sort( [ cur_cor_nod, cur_per_nod ] );
            del_edg_count                                                  = del_edg_count + 1;
            del_edg_ind( del_edg_count )                                   = ( node_pair( 2 ) - 1 )*n + node_pair( 1 );                    
            if is_nod0_or_deg1_inc == 0                     
                nod_inc_mat( inc_nod_id, per_deg )                         = nod_inc_mat( inc_nod_id, per_deg ) - 1;
                if per_deg > 1
                    [ is_inc, inc_nod_ids ]                                = ismember( per_nei_nod_inc_set, inc_nod_set );
                    inc_nod_ids                                            = setdiff( inc_nod_ids, inc_nod_id );
                    nod_inc_mat( inc_nod_ids, per_deg )                    = nod_inc_mat( inc_nod_ids, per_deg ) - 1;
                    nod_inc_mat( inc_nod_ids, per_deg - 1 )                = nod_inc_mat( inc_nod_ids, per_deg - 1 ) + 1;
                    cur_cor_deg                                            = cur_nod_deg( per_nei_deg_inc_set );   
                    uni_deg                                                = unique( cur_cor_deg );
                    if length( uni_deg ) == 1
                        deg_inc_mat( uni_deg, per_deg )                    = deg_inc_mat( uni_deg, per_deg ) - length( cur_cor_deg );
                        deg_inc_mat( uni_deg, per_deg - 1 )                = deg_inc_mat( uni_deg, per_deg - 1 ) + length( cur_cor_deg );
                    elseif length( uni_deg ) > 1
                        his_num                                            = hist( cur_cor_deg, uni_deg );
                        deg_inc_mat( uni_deg, per_deg )                    = deg_inc_mat( uni_deg, per_deg ) - his_num';
                        deg_inc_mat( uni_deg, per_deg - 1 )                = deg_inc_mat( uni_deg, per_deg - 1 ) + his_num';
                    end        
                end
            else
                deg_inc_mat( cor_deg, per_deg )                            = deg_inc_mat( cor_deg, per_deg ) - 1;       
                if per_deg > 1
                    cur_cor_deg                                            = cur_nod_deg( setdiff( per_nei_deg_inc_set, cur_cor_nod ) );   
                    uni_deg                                                = unique( cur_cor_deg );
                    if length( uni_deg ) == 1
                        deg_inc_mat( uni_deg, per_deg )                    = deg_inc_mat( uni_deg, per_deg ) - length( cur_cor_deg );
                        deg_inc_mat( uni_deg, per_deg - 1 )                = deg_inc_mat( uni_deg, per_deg - 1 ) + length( cur_cor_deg );
                    elseif length( uni_deg ) > 1
                        his_num                                            = hist( cur_cor_deg, uni_deg );
                        deg_inc_mat( uni_deg, per_deg )                    = deg_inc_mat( uni_deg, per_deg ) - his_num';
                        deg_inc_mat( uni_deg, per_deg - 1 )                = deg_inc_mat( uni_deg, per_deg - 1 ) + his_num';
                    end   
                    [ is_inc, inc_nod_ids ]                                = ismember( per_nei_nod_inc_set, inc_nod_set );
                    nod_inc_mat( inc_nod_ids, per_deg )                    = nod_inc_mat( inc_nod_ids, per_deg ) - 1;
                    nod_inc_mat( inc_nod_ids, per_deg - 1 )                = nod_inc_mat( inc_nod_ids, per_deg - 1 ) + 1;                    
                end
                cor_nei_nod_set                                            = nei_node_sets( [ nei_pointer( cur_cor_nod ): 1: nei_pointer( cur_cor_nod ) + cur_nod_deg( cur_cor_nod ) - 1 ] );
                if cor_deg > 1
                    cur_per_deg                                            = cur_nod_deg( setdiff( cor_nei_nod_set, cur_per_nod ) );
                    cur_per_deg                                            = cur_per_deg( find( cur_per_deg >= 1 ) );
                    uni_deg                                                = unique( cur_per_deg );
                    if length( uni_deg ) == 1
                        deg_inc_mat( cor_deg, uni_deg )                    = deg_inc_mat( cor_deg, uni_deg ) - length( cur_per_deg );
                        deg_inc_mat( cor_deg - 1, uni_deg )                = deg_inc_mat( cor_deg - 1, uni_deg ) + length( cur_per_deg );  
                    elseif length( uni_deg ) > 1                        
                        his_num                                            = hist( cur_per_deg, uni_deg );   
                        deg_inc_mat( cor_deg, uni_deg )                    = deg_inc_mat( cor_deg, uni_deg ) - his_num;
                        deg_inc_mat( cor_deg - 1, uni_deg )                = deg_inc_mat( cor_deg - 1, uni_deg ) + his_num;  
                    end  
                end    
            end
            pos                                                            = find( nei_node_sets( [ nei_pointer( cur_cor_nod ): 1: nei_pointer( cur_cor_nod ) + cur_nod_deg( cur_cor_nod ) - 1 ] ) == cur_per_nod );
            nei_node_sets( nei_pointer( cur_cor_nod ) + pos - 1 )          = nei_node_sets( nei_pointer( cur_cor_nod ) + cur_nod_deg( cur_cor_nod ) - 1 );
            cur_nod_deg( cur_cor_nod )                                     = cur_nod_deg( cur_cor_nod ) - 1;                    
            pos                                                            = find( cor_deg2nod_set( [ cor_deg2nod_ind( cor_deg ): 1: cor_deg2nod_ind( cor_deg + 1 ) - 1 ] ) == cur2cor_nodtra( cur_cor_nod ) );
            tem                                                            = cor_deg2nod_set( cor_deg2nod_ind( cor_deg ) );
            cor_deg2nod_set( cor_deg2nod_ind( cor_deg ) )                  = cor_deg2nod_set( cor_deg2nod_ind( cor_deg ) + pos - 1 );
            cor_deg2nod_set( cor_deg2nod_ind( cor_deg ) + pos - 1 )        = tem;
            cor_deg2nod_ind( cor_deg )                                     = cor_deg2nod_ind( cor_deg ) + 1;     
            pos                                                            = find( nei_node_sets( [ nei_pointer( cur_per_nod ): 1: nei_pointer( cur_per_nod ) + cur_nod_deg( cur_per_nod ) - 1 ] ) == cur_cor_nod );
            nei_node_sets( nei_pointer( cur_per_nod ) + pos - 1 )          = nei_node_sets( nei_pointer( cur_per_nod ) + cur_nod_deg( cur_per_nod ) - 1 );
            cur_nod_deg( cur_per_nod )                                     = cur_nod_deg( cur_per_nod ) - 1; 
            pos                                                            = find( per_deg2nod_set( [ per_deg2nod_ind( per_deg ): 1: per_deg2nod_ind( per_deg + 1 ) - 1 ] ) == cur2per_nodtra( cur_per_nod ) );
            tem                                                            = per_deg2nod_set( per_deg2nod_ind( per_deg ) );
            per_deg2nod_set( per_deg2nod_ind( per_deg ) )                  = per_deg2nod_set( per_deg2nod_ind( per_deg ) + pos - 1 );
            per_deg2nod_set( per_deg2nod_ind( per_deg ) + pos - 1 )        = tem;
            per_deg2nod_ind( per_deg )                                     = per_deg2nod_ind( per_deg ) + 1;  
            step_count                                                     = step_count + 1;
            if step_count >= cur_step_num
                break;
            end            
        end
        if is_nod0_or_deg1_inc == 0
            nod_inc_edg_num                                               = nod_inc_edg_num - step_count;     
        else
            deg_inc_edg_num                                               = deg_inc_edg_num - step_count;
        end            
        if step_count > 0 & is_first_cor == 0
            if is_nod0_or_deg1_inc == 0
                cor_deg_nod_num( cor_deg + step_count - 1 )               = cor_deg_nod_num( cor_deg + step_count - 1 ) - 1;
                if cor_deg > 1
                    change_percentage                                     = 1/cur_cor_nod_num;
                    cur_cor_deg_dis( cor_deg + step_count - 1 )           = cur_cor_deg_dis( cor_deg + step_count - 1 ) - change_percentage;
                    cor_deg_nod_num( cor_deg - 1 )                        = cor_deg_nod_num( cor_deg - 1 ) + 1;
                    cur_cor_deg_dis( cor_deg - 1 )                        = cur_cor_deg_dis( cor_deg - 1 ) + change_percentage;
                else
                    cur_cor_nod_num                                       = cur_cor_nod_num - 1;
                    cur_cor_deg_dis                                       = cor_deg_nod_num/cur_cor_nod_num;
                end
            else                        
                cor_deg_nod_num( cor_deg )                                = cor_deg_nod_num( cor_deg ) - step_count;
                if cor_deg > 1
                    change_percentage                                     = step_count/cur_cor_nod_num;
                    cur_cor_deg_dis( cor_deg )                            = cur_cor_deg_dis( cor_deg ) - change_percentage;
                    cor_deg_nod_num( cor_deg - 1 )                        = cor_deg_nod_num( cor_deg - 1 ) + step_count;
                    cur_cor_deg_dis( cor_deg - 1 )                        = cur_cor_deg_dis( cor_deg - 1 ) + change_percentage;
                else
                    cur_cor_nod_num                                       = cur_cor_nod_num - step_count;
                    cur_cor_deg_dis                                       = cor_deg_nod_num/cur_cor_nod_num;
                end
            end
            cor_distance                                                  = norm( cur_cor_deg_dis - ini_cor_deg_dis, inf );
        end 
        if step_count > 0 & is_first_per == 0    
            per_deg_nod_num( per_deg )                                     = per_deg_nod_num( per_deg ) - step_count;
            if per_deg > 1
                change_percentage                                          = step_count/cur_per_nod_num;
                cur_per_deg_dis( per_deg )                                 = cur_per_deg_dis( per_deg ) - change_percentage;
                per_deg_nod_num( per_deg - 1 )                             = per_deg_nod_num( per_deg - 1 ) + step_count;
                cur_per_deg_dis( per_deg - 1 )                             = cur_per_deg_dis( per_deg - 1 ) + change_percentage;
            else
                cur_per_nod_num                                            = cur_per_nod_num - step_count;
                cur_per_deg_dis                                            = per_deg_nod_num/cur_per_nod_num;
            end
            per_distance                                                   = norm( cur_per_deg_dis - ini_per_deg_dis, inf );
        end 
    end 
    [is_inc, del_pos ]                                                     = ismember( del_edg_ind( [ 1: 1: del_edg_count ] ), all_edg_ind );
    BP_sampled_matrix                                                      = p_Matrix( setdiff( [ 1: 1: all_edg_num ], del_pos ), : ); 
    bipartite_sampling_ratio                                               = del_edg_count/all_edg_num;
end

